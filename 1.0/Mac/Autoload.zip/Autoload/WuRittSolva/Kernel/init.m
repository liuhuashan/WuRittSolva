(* :Title: WuRittSolva`*)

(* :Summary: WuRittSolva`
  
   This package is written for solving systems of polynomial equations,and the main       algorithm is based on Wu's Method.

   Polynomial factorization over rational field may be used to reduce the sizes of the   polynomials produced in the Well-Ordering process.

*)

(* :Author: 

   Huashan Liu,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Republic of China
   E-Mail:liukaitanpidi@sina.com
   HomePage:http://magicm.51.net

   Instructor:
   Associate Prof. Huang DongWei,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Repulic of China

*)

(* :Reference:

   [1].Original algorithm of the general process is out of Mr. Wu Wentsun 's works(like ON MATHEMATICS MECHANNIZATION) and some others' books such as SELECTED PAPERS IN SIMBOLIC COMPUTATION(By Doc. Wang DongMing etc.), ARITHMETIC  ALGEBRA(By Bhubaneswar Mishra),etc..

   [2].Referential realization in any computer algebra language is helpful.The available package is WSOLVE in Maple format at present.
   Note:
   WSOLVE of Maple V realease 3 is developped by Doctor Wang DingKang,
   Mathematics Mechanization Research Center(abbrev. MMRC),
   Chinese Academic Scinica(abbrev. CAS)
   WebAdress:http://mmrc.iss.ac.cn/
   
   [3].Stephen Wolfram,The Mathematica Book,4th ed.(Wolfram Media/Cambridge University Press, 1999).

*)


(* :History: File created on March 4th,2005 *)

(*Initilization*)
If[! MemberQ[$Packages, "WuRittSolva`"],
     System`Private`p = Unprotect[$Packages];
     PrependTo[$Packages, "WuRittSolva`"];
     Protect @@ System`Private`p
];


DeclarePackage["WuRittSolva`Master`",{"MaxElementPos","MinElementPos","IsConstantsIn","PolyVariables","FixedClass","AutoClass","Class","FixedMainVariable","AutoMainVariable","MainVariable","MainVariableExponent","Initial","IsPolyReduced","LeadCoefficient","PolynomialRank","IsRankEqual","IsRankLess","IsRankGreater","intTest","orderTransform","Separant","IsCompatibleSet","IsIncompatibleSet"}]


DeclarePackage["WuRittSolva`WuRittSolva`",{"PolyPRemainder","PseudoRemainder","PseudoResolution","AuxPseudoRemainder","AuxPseudoResolution","PseudoRemainderSet","PseudoResolutionSet","IsAscendingSet","SplitPolySet","MiniAscSet","BasicSet","CharacteristicSet","CharacteristicForm","WuRittEqnsSolve","Padding","TracePrintOn","MaxSteps","ZerosDecomposition"}]


DeclarePackage["WuRittSolva`WuRittProver`",{"IsNewComponent","AuxProverRemainder","WuRittProver","WuRittSmartProver","TraceCharacteristicSetOn","TraceProverOn"}]


DeclarePackage["WuRittSolva`Geo2AlgLib`",{"TwoLinesParallel","TwoLinesPerpend","TriplePointsCollinear","PointOnLineEqual","PointOnLineToRatio","TwoLinesEqual","TwoLinesToRatio","TripleLinesIntersect","TwoLinesEqualRatio","TwoAnglesEqual","PointInAngle","PointOnCirlce","TwoPointsOnCircle","ThreePointsOnCircle","FourPointsOnCircle","FivePointsOnCircle"}]


(* End of init package *)
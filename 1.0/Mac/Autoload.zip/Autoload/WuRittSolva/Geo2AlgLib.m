(* :Title: Geo2AlgLib Part of WuRittSolva *)

(* :Author:

   Huashan Liu,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Republic of China
   E-Mail:liukaitanpidi@sina.com
   HomePage:http://magicm.51.net

   Instructor:
   Associate Prof. Huang DongWei,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Repulic of China

*)

(* :Summary:
  
   This package is written for building a algebraic polynomial-libaray for geometry-algebra relations in geometry configuration.

   The geo2alglib should be updated dynamicly, but until now we can only to 
implement pre-library for normal user. The advance user can program his/her own 
_geo2alglib for special purpose, but we will add new polynomail-branchs into this
lib now and then.

*)

(* :Context: WuRittSolva`Geo2AlgLib` *)

(* :Package Version: 1.0 *)

(* :Copyright: Copyright 2005 *)

(* :History:1.0: original version, 2005.*)

(* :Keywords: Geo2AlgLib, WuRittSolva*)

(* :Source: None. *)

(* :Warning: Expands the definition of Column. *)

(* :Mathematica Version: 4.2 or later *)

(* :Limitation: None known. *)

(* :Discussion: 

    The key problem is focused on how to fix a proper characteristic set. If proper, the  following steps maybe become more elegant, else more complex. In the concrete steps, factorization on rational filed is helpful to simplify the computation by the Nulls Configuration Theorems or Wu Wentsun Principles.

   The short input of geometry-to-algebraic relation is important for user's working effect. Here we prepare some algebraic polynomials for common geometry configuration.
These polynomials can be generated from the initial configuration of geometry automaticly.

*)

(* :Reference:

   [1].Original algorithm of the general process is out of Mr. Wu Wentsun 's works(like ON MATHEMATICS MECHANNIZATION) and some others' books such as SELECTED PAPERS IN SIMBOLIC COMPUTATION(By Doc. Wang DongMing etc.), ARITHMETIC  ALGEBRA(By Bhubaneswar Mishra),etc..

   [2].Referential realization in any computer algebra language is helpful.The available package is WSOLVE in Maple format at present.
   Note:
   WSOLVE of Maple V realease 3 is developped by Doctor Wang DingKang,
   Mathematics Mechanization Research Center(abbrev. MMRC),
   Chinese Academic Scinica(abbrev. CAS)
   WebAdress:http://mmrc.iss.ac.cn/
   
   [3].Stephen Wolfram,The Mathematica Book,4th ed.(Wolfram Media/Cambridge University Press, 1999).

*)


(* istory: File created on March 4th,2005 *)

BeginPackage["WuRittSolva`Geo2AlgLib`",{"WuRittSolva`Master`"},{"WuRittSolva`WuRittProver`"}]


(*Usage for System Functions*)

TwoLinesParallel::usage = "TwoLinesParallel[{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}}] returns the algebraic polynomial representing AB//CD."

TwoLinesPerpend::usage = "TwoLinesPerpend[{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}}] returns the algebraic polynomial representing Perp.(AB,CD)."

TriplePointsCollinear::usage = "TriplePointsCollinear[{x1,y1},{x2,y2},{x3,y3}] returns the algebraic polynomial representing ABC collinear."

PointOnLineEqual::usage = "PointOnLineEqual[{x2,y2},{{x1,y1},{x3,y3}}] returns the algebraic polynomial representing B is the middle point of AC."

PointOnLineToRatio::usage = "PointOnLineToRatio[{x3,y3},{{x1,y1},{x2,y2}},ratio] returns the algebraic polynomial representing AC/BC = ratio."

TwoLinesEqual::usage = "TwoLinesEqual[{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}}] returns the algebraic polynomial representing |AB| = |CD|."

TwoLinesToRatio::usage = "TwoLinesToRatio[{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}},ratio] returns the algebraic polynomial representing AB/CD = ratio."

TripleLinesIntersect::usage = "TripleLinesIntersect[{x7, y7},{{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}},{{x5,y5},{x6,y6}}}] returns the algebraic polynomial representing AB��CD��EF = G."

TwoLinesEqualRatio::usage = "TwoLinesEqualRatio[{{{x1,y1},{x2,y2}},{{x3,y3},{x4,y4}}},{{{x5,y5},{x6,y6}},{{x7,y7},{x8,y8}}}] returns the algebraic polynomial representing AB/CD = EF/GH = ratio."

TwoAnglesEqual::usage = "TwoAnglesEqual[{{x1,y1},{x2,y2},{x3,y3}},{{x4,y4},{x5,y5},{x6, y6}}] returns the algebraic polynomial representing Angle(ABC) = Angle(DEF)."

PointInAngle::usage = "PointInAngle[{x4,y4},{{x1,y1},{x2,y2},{x3,y3}}] returns the algebraic polynomial representing D on the bisector of Angle(ABC)."

PointOnCirlce::usage = "PointOnCirlce[{x2,y2},{{x1,y1},radius}] returns the algebraic polynomial representing B on circle(A, radius)."

TwoPointsOnCircle::usage = "TwoPointsOnCircle[{{x1,y1},{x2,y2}},{{x3,y3},radius}] returns the algebraic polynomial representing A, B on cirlce(C, radius)."

ThreePointsOnCircle::usage = "ThreePointsOnCircle[{{x1,y1},{x2,y2},{x3,y3}},{{x4,y4},radius}] returns the algebraic polynomial representing A, B, C on cirlce(D, radius)."

FourPointsOnCircle::usage = "FourPointsOnCircle[{{x1,y1},{x2,y2},{x3,y3},{x4,y4}},{{x5,y5}, radius}] returns the algebraic polynomial representing A, B, C, D on circle(E, radius)."

FivePointsOnCircle::usage = "FivePointsOnCircle[{{x1,y1},{x2,y2},{x3,y3},{x4,y4},{x5,y5}},{{x6, y6},radius}] returns the algebraic polynomial representing A, B, C, D, E on circle(F,radius)."

(*SYSTEM MESSAGE *)

poly::"warning" = "In ps = `1`, lvar is called with constant.";


Begin["`Private`"]


(*THIS CANCELS THE SPELLING CHECKING*)

Off[General::"spell1"];


(* Begin of the Geometry to Algebra Library *)


TwoLinesParallel[{{x1_, y1_},{x2_, y2_}}, {{x3_, y3_},{x4_, y4_}}] := 
Module[{tmp},
    tmp = (x2 - x1)(y4 - y3) - (x4 - x3)(y2 - y1);
    Return[tmp];
    ]

TwoLinesPerpend[{{x1_, y1_},{x2_, y2_}}, {{x3_, y3_},{x4_, y4_}}] :=
Module[{tmp},
     tmp = (x2 - x1)(x4 - x3) + (y2 - y1)(y4 - y3);
    Return[tmp];
]

TriplePointsCollinear[{x1_, y1_}, {x2_, y2_}, {x3_, y3_}] := 
Module[{tmp},
    tmp = (x2 - x1)(y3 - y1) - (x3 - x1)(y2 - y1);
    Return[tmp];
    ]

PointOnLineEqual[{x2_, y2_}, {{x1_, y1_}, {x3_, y3_}}] := Module[{tmp},
    tmp = (2x2 - x1 - x3)(2y2 - y1 - y3);
    Return[tmp];
    ]

PointOnLineToRatio[{x3_, y3_}, {{x1_, y1_}, {x2_, y2_}}, ratio_:1/2] := 
    Module[{tmp},
    tmp = (x3 - x1 - ratio(x2 - x3))(y3 - y1 - ratio(y2 - y3));
    Return[tmp];
    ]

TwoLinesEqual[{{x1_, y1_}, {x2_, y2_}}, {{x3_, y3_}, {x4_, y4_}}] := 
Module[{tmp},
    tmp = (x2 - x1)^2 + (y2 - y1)^2 - (x4 - x3)^2 - (y4 - y3)^2;
    Return[tmp];
    ]

TwoLinesToRatio[{{x1_, y1_}, {x2_, y2_}}, {{x3_, y3_}, {x4_, y4_}}, ratio_:1/2] := 
Module[{tmp},
    tmp = (x2 - x1)^2 + (y2 - y1)^2 - ratio^2[(x4 - x3)^2 - (y4 - y3)^2];
    Return[tmp];
    ]

TripleLinesIntersect[{x7_, y7_},{{{x1_, y1_}, {x2_, y2_}}, {{x3_, y3_}, {x4_, y4_}}, {{x5_, y5_}, {x6_, y6_}}}] := 
Module[{tmp}, tmp = CollRelation[{
              pointA, {x1, y1}}, {pointB, {x2, y2}}, {pointG, {x7, 
              y7}}]CollRelation[{pointC, {
          x3, y3}}, {pointD, {x4, y4}}, {pointG, {
          x7, y7}}]CollRelation[{pointE, {x5, y5}}, {pointF, {x6, 
            y6}}, {pointG, {x7, y7}}];
    Return[tmp];
    ]

TwoLinesEqualRatio[{{{x1_, y1_},{x2_, y2_}}, {{x3_, y3_}, {x4_, y4_}}}, {{{x5_, y5_}, {x6_, y6_}}, {{x7_, y7_},{x8_, y8_}}}] := 
Module[{tmp}, 
      tmp = ((x2 - x1)^2 + (y2 - y1)^2)((x8 - x7)^2 - (y8 - y7)^2) - ((
    x4 - x3)^2 + (y4 - y3)^2)((x6 - x5)^2 + (y6 - y5)^2);
    Return[tmp];
    ]

TwoAnglesEqual[{{x1_, y1_}, {x2_, y2_}, {x3_, y3_}}, {{x4_, y4_}, {x5_, y5_}, {x6_,y6_}}] := 
Module[{tmp}, 
tmp = ((x1 - x2)(y3 - y2) - (x3 -
     x2)(y1 - y2))((x4 - x5)(x6 - x5) + (y4 - y5)(y6 - y5)) - ((x4 -
       x5)(y6 - y5) - (x6 - x5)(y4 -
   y5))((x1 - x2)(x3 - x2) + (y1 - y2)(y3 - y2));
    Return[tmp];
    ]

PointInAngle[{x4_, y4_}, {{x1_, y1_},{x2_, y2_},{x3_, y3_}}] := 
Module[{tmp}, 
tmp = ((x1 - x2)(
      y4 - y2) - (x4 - x2)(y1 - y2))((x4 - x2)(x3 - x2) + (y4 - y2)(
      y3 - y2)) - ((x4 - x5)(
        y3 - y2) - (x3 - x2)(y4 - y2))((x1 - x2)(x4 - x2) + (y1 - y2)(
    y4 - y2));
    Return[tmp];
    ]

PointOnCirlce[{x2_, y2_}, {{x1_, y1_}, radius_:1}] := 
Module[{},
    tmp = (x2 - x1)^2 + (y2 - y1)^2 - radius^2;
    Return[tmp];
    ]

TwoPointsOnCircle[{{x1_, y1_},{x2_, y2_}}, {{x3_, y3_}, radius_:1}] := 
Module[{tmp},
    tmp = ((x1 - x3)^2 + (y1 - y3)^2 - radius^2)((x2 - x3)^2 + (y2 - 
            y3)^2 - radius^2);
    Return[tmp];
    ]

ThreePointsOnCircle[{{x1_, y1_},{x2_, y2_}, {x3_, y3_}}, {{x4_, y4_},radius_:1}] := 
Module[{tmp}, tmp = ((x1 - x4)^2 + (y1 - y4)^2 - radius^2)((x2 - x4)^2 + (y2 - 
            y4)^2 - radius^2)((x3 - x4)^2 + (y3 - y4)^2 - radius^2);
    Return[tmp];
    ]

FourPointsOnCircle[{{x1_, y1_}, {x2_, y2_}, {x3_, y3_}, {x4_, y4_}}, {{x5_, y5_}, radius_:1}] := 
    Module[{tmp}, 
tmp = ((x1 - x5)^2 + (y1 - y5)^2 - radius^2)((x2 - 
      x5)^2 + (y2 - y5)^2 - radius^2)((x3 - x5)^2 + (y3 - y5)^2 - 
      radius^2)((x4 - x5)^2 + (y4 - y5)^2 - radius^2);
    Return[tmp];
    ]

FivePointsOnCircle[{{x1_, y1_},{x2_, y2_},{x3_, y3_},{x4_, y4_},{x5_, y5_}},{{x6_, y6_}, radius_:1}] := Module[{tmp}, 
tmp = ((x1 - x6)^2 + (y1 - y6)^2 - radius^2)((
            x2 - x6)^2 + (y2 - y6)^2 - 
            radius^2)((x3 - x6)^2 + (y3 - y6)^2 - radius^2)((
            x4 - x6)^2 + (y4 - y6)^2 - 
            radius^2)((x5 - x6)^2 + (y5 - y6)^2 - radius^2);
    Return[tmp];
    ]

(* End of the Geometry to Algebra Library *)


(*THIS ENSURES THE SPELLING CHECKING*)

On[General::"spell1"];

End[ ]

SetAttributes[ Geo2AlgLib ,ReadProtected];

Protect[ Geo2AlgLib ];

EndPackage[ ]

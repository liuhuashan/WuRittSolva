
		              Readme

--------------------------------------------------------------------------------------

                   WuRittSolva     CopyRight (c) 2005 Liu Hua-Shan
Contact me for Advice or bugs:     liukaitianpidi@sina.com
                      Version:     1.0
                 Release date:     06-21-2005

--------------------------------------------------------------------------------------

1.What is WuRittSolva

WuRittSolva is a standard application pacakge for computer algebra system Mathematica(TM) developped by Liu Hua-Shan for mechanization mathematics education purpose at present. It introduces the Wu-Ritt Well-Order Principle and Zero-Decompostion Theorem as its key theory considering points, and has implemented the most operation for normal polynomials proccessing, such as fixing CLASS, MAIN VARIABLE, SEPARANT, POLYNOMIAL RANK, BASIC SET, CHARACTERISTIC SET and so on. What is more, it supplies smart functions for elementary geometry theorems proving, promising proving theorems in smart way.

It strongerly advizes that the polynomials appearing for functions in WuRittSolva are belong to polynomail ring K[u_1,u_2,...,u_n;x_1,x_2,...,x_n] such that the results may be more perfect for understanding.

2.Function Systems and Features
2.1 Functions in Master.m

{"MaxElementPos","MinElementPos","IsConstantsIn","PolyVariables","FixedClass","AutoClass","Class","FixedMainVariable","AutoMainVariable","MainVariable","MainVariableExponent","Initial","IsPolyReduced","LeadCoefficient","PolynomialRank","IsRankEqual","IsRankLess","IsRankGreater","intTest","orderTransform","Separant","IsCompatibleSet","IsIncompatibleSet"}

2.2 Functions in WuRittSolva.m

{"PolyPRemainder","PseudoRemainder","PseudoResolution","AuxPseudoRemainder","AuxPseudoResolution","PseudoRemainderSet","PseudoResolutionSet","IsAscendingSet","SplitPolySet","MiniAscSet","BasicSet","CharacteristicSet","CharacteristicForm","WuRittEqnsSolve","Padding","TracePrintOn","MaxSteps","ZerosDecomposition"}

2.3 Functions in Geo2AlgLib.m

{"TwoLinesParallel","TwoLinesPerpend","TriplePointsCollinear","PointOnLineEqual","PointOnLineToRatio","TwoLinesEqual","TwoLinesToRatio","TripleLinesIntersect","TwoLinesEqualRatio","TwoAnglesEqual","PointInAngle","PointOnCirlce","TwoPointsOnCircle","ThreePointsOnCircle","FourPointsOnCircle","FivePointsOnCircle"}

2.4 Functions in WuRittProver

{"IsNewComponent","AuxProverRemainder","WuRittProver","WuRittSmartProver","TraceCharacteristicSetOn","TraceProverOn"}

2.5 Features of Function Systems

"Master.m" supplies basic functions for other dot m files so as to make the package easy to update.
"WuRittSolva.m" implements the most key process for characteristic set such as pseudo division, basic set, characteristic set and so on.
"Geo2AlgLib.m" supplies geometry-to-algebra relations library for elementatry goemtric theorems presentation and proving.
"WuRittProver.m" implements some prover for mechanical proving.

3.Future Work

This work is mainly for education purpose of WuRitt characteristic set method from now on.

Up to now, the main components in mechanzation mathematics that have been implemented in WuRittSolva are only the basic algorithms of characteristic set method and also simple geometry theorem proving functions. This package WuRittSolva, however, shall introduce more algorithms for relavant subjects, including algebraic vairities simplifying, PDEs reducing, algebraic curves and surfaces representing and differential characteristic set method with corresponding objects.

4.What is Else


WuRittSolva1.0 

firstly considered since May 1st 2004.

programmed from March 1st 2005 to June 21st 2005

    developped by Liu Hua-Shan[*]

    inspected by Associate Prof. Huang Dong-Wei,Dept. of Maths, TJPU, Tianjin

Thankfulness to 
	
	Dr. Wang Ding-Kang of MMRC, KLMM, CAS

        Prof. Chen Zhi-Jie of Dept. of Maths, ENCU, ShangHai

for their advice and encouragement and kindeness

[*]
Bachelor Mayjor in 
Applied Mathematics and Softeware Engineering
Shcool of Science and School of Softeware
Tianjin Polytechnic University, P.R.China
HomePage : http://magicm.51.net
E-Mail   : liukaitianpidi@sina.com
CopyRights (c) 2005 Liu Hua-Shan


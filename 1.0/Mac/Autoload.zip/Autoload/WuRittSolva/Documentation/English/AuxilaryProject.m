{"Name" -> "WuRittSolva", "Directory" -> "C:\\Program Files\\Wolfram \
Research\\Mathematica\\5.0\\AddOns\\Autoload\\WuRittSolva\\Documentation\\Eng\
lish\\", "Files" -> {"A Collection of Testing Problems.nb", 
   "Demonstration of WuRittSolva in Elementary Geometry.nb", 
   "Demostration of WuRittSolva.nb", "Details of WuRittSolva.nb", "WuRittSolv\
a for Concrete Geometric Configurations in Elementary Geometry.nb", 
   "WuRittSolva Tools.nb", "WuRittSolva UserGuide.nb", 
   "WuRittSolva User Manual.nb"}}

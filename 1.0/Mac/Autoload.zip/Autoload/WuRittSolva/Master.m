(* :Title: Master Part of WuRittSolva *)

(* :Author:

   Huashan Liu,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Republic of China
   E-Mail:liukaitanpidi@sina.com
   HomePage:http://magicm.51.net

   Instructor:
   Associate Prof. Huang DongWei,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Repulic of China

*)

(* :Summary:
  
   This package is written for some pre-function for Wu-Ritt process, they are useful but should be updated for professional job.

*)

(* :Context: WuRittSolva`Master` *)

(* :Package Version: 1.0 *)

(* :Copyright: Copyright 2005 *)

(* :History:1.0: Original Version, 2005.*)

(* :Keywords: WuRitt Process, WuRittSolva*)

(* :Source: None. *)

(* :Warning: Expands the definition of Column. *)

(* :Mathematica Version: 4.2 or later *)

(* :Limitation: None known. *)

(* :Discussion:

   The key problem is focused on how to fix a proper characteristic set. If proper, the  following steps maybe become more elegant, else more complex. In the concrete steps, factorization on rational filed is helpful to simplify the computation by the Nulls Configuration Theorems or Wu Wentsun Principles.

*)

(* :Reference:

   [1].Original algorithm of the general process is out of Mr. Wu Wentsun 's works(like ON MATHEMATICS MECHANNIZATION) and some others' books such as SELECTED PAPERS IN SIMBOLIC COMPUTATION(By Doc. Wang DongMing etc.), ARITHMETIC  ALGEBRA(By Bhubaneswar Mishra),etc..

   [2].Referential realization in any computer algebra language is helpful.The available package is WSOLVE in Maple format at present.
   Note:
   WSOLVE of Maple V realease 3 is developped by Doctor Wang DingKang,
   Mathematics Mechanization Research Center(abbrev. MMRC),
   Chinese Academic Scinica(abbrev. CAS)
   WebAdress:http://mmrc.iss.ac.cn/
   
   [3].Stephen Wolfram,The Mathematica Book,4th ed.(Wolfram Media/Cambridge University Press, 1999).

*)


(* :History: File created on March 4th,2005 *)

BeginPackage["WuRittSolva`Master`"]

(*Usage for System Functions*)

MaxElementPos::usage = "MaxElementPos[list] gives the position of  maximal element in list."

MinElementPos::usage = "MinElementPos[list] gives the position of  minimal element in list."

IsConstantsIn::usage = "IsConstantsIn[list] gives the boolean value True if there are constants in list such as integers,reals etc; else False."

PolyVariables::usage = "PolyVariables[poly,const] gives the variables of poly assuming const as constants or non-variables."

FixedClass::usage = "FixedClass[poly,ord] gives the class of poly wrt ord."

AutoClass::usage = "AutoClass[poly,const] gives the class of poly automaticly."

Class::usage = "Class[poly,ord,const] returns the class of poly wrt ord or automaticly."

FixedMainVariable::usage = "FixedMainVariable[poly,ord,const] gives the main variable of poly wrt ord."

AutoMainVariable::usage= "AutoMainVariable[poly,const] gives the main variable of poly automaticly."

MainVariable::usage = "MainVariable[poly,ord,const] returns the main variable of poly."

MainVariableExponent::usage = "MainVariableExponent[poly,ord,const] returns the maximal exponent of main variable of poly wrt ord or automaticly."

Initial::usage = "Initial[poly,ord,const] returns the Initial of poly wrt ord or automaticly."

LeadCoefficient::usage = "LeadCoefficient[poly,var] returns the leading coefficient wrt var, this functions is equivelent to Initial anyway."

PolynomialRank::usage = "PolynomialRank[lhspoly,ord,const] returns the rank of lhspoly wrt ord with const as constants."

IsRankEqual::usage = "IsRankEqual[lhspoly,rhspoly,ord,const] returns the boolean value True if rank of lhspoly is equal to rank of rhspoly wrt ord with const as constants."

IsRankLess::usage = "IsRankLess[lhspoly,rhspoly,ord,const] returns the boolean value True if rank of lhspoly is less to rank of rhspoly wrt ord with const as constants."

IsRankGreater::usage = "IsRankGreater[lhspoly,rhspoly,ord,const] returns the boolean value True if rank of lhspoly is greater to rank of rhspoly wrt ord with const as constants."

IsPolyReduced::usage = "IsPolyReduced[lhspoly, rhspoly, ord, const] returns the boolean value True if lhspoly is reduced to rhspoly wrt ord with const as constants."

IsCompatibleSet::usage = "IsCompatibleSet[polyset,const] returns boolean value True if the polyset is compatible set."

IsIncompatibleSet::usage = "IsIncompatibleSet[polyset,const] returns boolean value True if the polyset is incompatible set."

(*System Message *)

poly::"warning" = "In ps = `1`, lvar is called with constant.";
MainVarialbe::"Automatic" = "System can not fix main variable wrt ord `1`, and selects `2` automaticly."
IsPolyReduced::"Reduced" = "`1` is reduced to `2`.";

IsPolyReduced::"NotReduced" = "`1` is not reduced to `2`.";

Begin["`Private`"]


(*this cancels the spelling checking*)

Off[General::"spell1"];
Off[Set::"write"];

(*begin for opts*)
filterOpts[ command_Symbol, options___ ] :=
	FilterOptions[ First /@ Options[command], options ]

filterOpts[ opts_List, options___ ] :=
	Sequence @@ Select[ Flatten[{options}], MemberQ[opts, First[#]]& ]
(* end for opts*)


(*begin of some common funtions defined for list manipulation*)

MaxElementPos[list_]:=Position[list,Max[list]][[1,1]];
MinElementPos[list_]:=Position[list,Min[list]][[1,1]];

IsConstantsIn[list_] :=
  Module[{tmp},
    tmp = Select[list, IntegerQ];
    If[Length@tmp > 0, Return[True], Return[False]];
    Return[False];
    ]
Options[ PolyVariable ] = { } ~Joind~Options[ Variables ]

PolyVariables[poly_,const___:{}]:=
  Module[{tmp},
    tmp=Complement[Variables[poly],const];
    Return[tmp];
    ]

IsPolyReduced[lhspoly_, rhspoly_, ord___, const___] :=
  Module[{tmp},
    tmp = If[Class[rhspoly, ord, const] <
   Class[lhspoly, ord, const] || (Class[
    rhspoly, ord, 
      const] == Class[lhspoly, ord, const] && MainVariableExponent[rhspoly,
             ord, const] < MainVariableExponent[lhspoly, ord, const]),
        (*Message[IsPolyReduced::"Reduced", rhspoly, lhspoly];*)
                True,(*Message[IsPolyReduced::"NotReduced",
                   rhspoly, lhspoly];*)False];
    Return[tmp];
    ]


intTest[lst_]:=Module[{tmp},tmp=Select[lst,Not[IntegerQ[#]]&];
    Return[tmp];]

orderTransform[ord_?ListQ]:=
  Module[{tmp,res},
    tmp=Table[ToExpression@StringJoin["$",ToString[i]],{i,1,Length@ord}];
    res=Transpose@MapThread[{#2\[Rule]#1,#1\[Rule]#2}&,{tmp,ord}];
    Return[res];]

(*END OF SOME COMMON FUNTIONS DEFINED FOR LIST MANIPULATION*)



(*BEGIN OF COMPUTATION OF POLY CLASS AND MAINVARIABLE WRT ORD.IF ORD IS UNKNOWN, THIS PROCEDURE MAY SELECT A MAIN VARIABLE THAT HAS MAXIMAL EXPONENT AND FIX ORDER BY LEXICAL RULE*)

Separant[poly_, ord_,const___] :=
  Module[{res},
    res=D[ps, MainVarialbe[ps, ord,const]];
    Return[res];
    ]

FixedClass[poly_,ord_]:=
Module[{},
tmp=Map[Exponent[poly,#]&,Sort[ord]];
mid=Last[Flatten[Position[tmp,Last[Select[tmp,Positive]]]]];
Return[ord[[mid]][[2]]];
]

FixedMainVariable[poly_,ord_,const___]:=Module[{tmp,mid,i},i=Length[ord];
    While[i>0,
      If[MemberQ[PolyVariables[poly,const],ord[[i]]],tmp=ord[[i]];Break[],
        tmp=Null];
      (*Print[ord[[i]]];*)
      i--];
    (*Print[tmp];*)
    If[tmp=!=Null, Return[tmp],(mid=Evaluate@AutoMainVariable[poly,const];Message[MainVarialbe::"Automatic",ord, mid];Return[mid];)];(*Automatic*)
    ]

AutoClass[poly_,const___]:=
Module[{tmp,mid},
tmp = PolyVariables[poly,const];
res = Last[tmp][[2]];
Return[res];
]

AutoMainVariable[poly_,const___]:=
Module[{tmp},
  tmp = PolyVariables[poly,const];
Return[Last[tmp]];
]

MainVariable[poly_,ord_:False,const___]:=
Module[{tmp},
tmp=If[Not[VectorQ[ord]],AutoMainVariable[poly,const],FixedMainVariable[poly,ord,const]];
Return[tmp];
]

Class[poly_,ord_:False,const___]:=
Module[{tmp},
tmp=If[VectorQ[ord],FixedClass[poly,ord] ,AutoClass[poly,const]];
Return[tmp];
]

(*END OF COMPUTATION OF CLASS AND MAINVARIABLE WRT ORD*)


(*BEGIN OF SOME RELATED FUNCTIONS*)

MainVariableExponent[poly_,ord___,const___]:=
Module[{tmp},
tmp=Exponent[poly,MainVariable[poly,ord,const]];
Return[tmp];
]

Initial[poly_,ord___,const___]:=
Module[{tmp,mid,res},
tmp=MainVariable[poly,ord,const];
mid=Exponent[poly,tmp];
res=Coefficient[poly,tmp^mid];
Return[Expand[res]];
]

LeadCoefficient[poly_, var_] :=
  Module[{tmp},
    tmp = Last@CoefficientList[poly, var];
    Return[Expand[tmp]];
]

(*END OF SOME RELATED FUNCTIONS*)


(*BEGIN OF POLYNOMIAL RANK PART*)

PolynomialRank[lhspoly_,ord___,const___]:=
  Module[{res},
    res={Class[lhspoly,ord,const],MainVariableExponent[lhspoly,ord,const]};
    Return[res];
    ]

IsRankEqual[lhspoly_,rhspoly_,ord___,const___]:=
  Module[{res},
    res=If[PolynomialRank[lhspoly,ord,const]==PolynomialRank[rhspoly,ord,
    const],True,False];
    Return[res];
    ]

IsRankLess[lhspoly_,rhspoly_,ord___,const___]:=
  Module[{lhsrank,rhsrank,res},
    lhsrank=PolynomialRank[lhspoly,ord,const];
    rhsrank=PolynomialRank[rhspoly,ord,const];
    res=If[lhsrank[[1]]<rhsrank[[1]]||(
        lhsrank[[1]]\[Equal]rhsrank[[1]]&&lhsrank[[2]]<
    rhsrank[[2]]),True,False];
    Return[res];
    ]

IsRankGreater[lhspoly_,rhspoly_,ord___,const___]:=
  Module[{res},
    res=If[Not[IsRankEqual[lhspoly,rhspoly,ord,const]]&&Not[IsRankLess[
    lhspoly,rhspoly,ord,const]],True,False];
    Return[res];
    ]

(*END OF  POLYNOMIAL RANK  PART*)

(*Begin of Compatible set*)

IsCompatibleSet[polyset_,const___]:=
  Module[{tmp,mid,res},
    tmp=PolyVariables[#,const]&/@polyset;
    mid=Select[tmp,Length[#]>0&];
    res=If[Length[mid]<Length[tmp],False,True];
    Return[res];
    ]

IsIncompatibleSet[polyset_,const___]:=
  Module[{res},
    res=If[IsCompatibleSet[polyset,const],False,True];
    Return[res];
    ]

(*End of Compatible set*)

(*THIS ENSURES THE SPELLING CHECKING*)

On[Set::"write"];
On[General::"spell1"];


End[ ]

SetAttributes[ Master ,ReadProtected];

Protect[ Master ];

EndPackage[ ]

(* :Title: WuRittSolva Part of WuRittSolva *)

(* :Author:

   Huashan Liu,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Republic of China
   E-Mail:liukaitanpidi@sina.com
   HomePage:http://magicm.51.net

   Instructor:
   Associate Prof. Huang DongWei,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Repulic of China

*)

(* :Summary:
  
   This package is written for solving systems of polynomial equations,and the main       algorithm is based on Wu's Method.

   Polynomial factorization over rational field may be used to reduce the sizes of the   polynomials produced in the Well-Ordering process.

*)

(* :Context: WuRittSolva`WuRittSolva` *)

(* :Package Version: 1.0 *)

(* :Copyright: Copyright 2005 *)

(* :History:1.0: original version, 2005.*)

(* :Keywords: WuRitt Process, WuRittSolva*)

(* :Source: None. *)

(* :Warning: Expands the definition of Column. *)

(* :Mathematica Version: 4.2 or later *)

(* :Limitation: None known. *)

(* :Discussion: 

    The key problem is focused on how to fix a proper characteristic set. If proper, the  following steps maybe become more elegant, else more complex. In the concrete steps, factorization on rational filed is helpful to simplify the computation by the Nulls Configuration Theorems or Wu Wentsun Principles.

*)

(* :Reference:

   [1].Original algorithm of the general process is out of Mr. Wu Wentsun 's works(like ON MATHEMATICS MECHANNIZATION) and some others' books such as SELECTED PAPERS IN SIMBOLIC COMPUTATION(By Doc. Wang DongMing etc.), ARITHMETIC  ALGEBRA(By Bhubaneswar Mishra),etc..

   [2].Referential realization in any computer algebra language is helpful.The available package is WSOLVE in Maple format at present.
   Note:
   WSOLVE of Maple V realease 3 is developped by Doctor Wang DingKang,
   Mathematics Mechanization Research Center(abbrev. MMRC),
   Chinese Academic Scinica(abbrev. CAS)
   WebAdress:http://mmrc.iss.ac.cn/
   
   [3].Stephen Wolfram,The Mathematica Book,4th ed.(Wolfram Media/Cambridge University Press, 1999).

*)


(* :History: File created on March 4th,2005 *)

BeginPackage["WuRittSolva`WuRittSolva`", {"WuRittSolva`Master`"},{"WuRittSolva`WuRittProver`"}]

Unprotect[CharacteristicSet,CharacteristicForm]

(*Usage for System Functions*)

PolyPRemainder::usage = "PolyPRemainder[lhspoly,rhspoly,var] returns the pseudo remaider of pseudo division of lhspoly to rhspoly wrt variable."

PseudoRemainder::usage = "PseudoRemainder[lhspoly,rhspoly,ord,const] returns the pseudo remainder of pseudo division of lhspoly to rhspoly wrt ord or automaticly with const as constant variables."

PseudoResolution::usage = "PseudoResolution[lhspoly,rhspoly,ord,const] returns the pseudo resolution of pseudo division of lhspoly to rhspoly wrt ord or automaticly with const as constant variables."

AuxPseudoRemainder::usage = "AuxPseudoRemainder[poly,polyset,ord,const] returns the pseudo remainder of pseudo division of poly to polyset wrt ord or automaticly with const as constant variables."

AuxPseudoResolution::usage = "AuxPseudoResolution[poly,polyset,ord,const] returns the pseudo resolution of pseudo division of poly to polyset wrt ord or automaticly with const as constant variables."

PseudoRemainderSet::usage = "PseudoRemainderSet[lhspolyset,rhspolyset,ord,const] returns the pseudo remainder of pseudo division of lhspolyset to rhspolyset wrt ord or automaticly with const as constant variables."

PseudoResolutionSet::usage = "PseudoResolutionSet[lhspolyset,rhspolyset,ord,const] returns the pseudo resolution set of pseudo division of lhspolyset to rhspolyset wrt ord or automaticly with const as constant variables."

IsAscendingSet::usage = "IsAscendingSet[polyset,ord,const] returns boolean value True if polyset is an asending set wrt ord or atuotmaticly with const as constant variables"

SplitPolySet::usage = "SplitPolySet[polyset,ord,const] returns the splited polynomials by the main variables wrt ord with const as constants."

BasicSet::usage = "BasicSet[polyset,ord,const] returns a basic set of polyset wrt ord wrt const as constants."

CharacteristicSet::usage = "CharacteristicSet[polyset,ord,const,opts] returns the characteristic set of polyset wrt ord with const as constants."

CharacteristicForm::usage = "CharacteristicForm[cspolyset,ord,const,opts] returns the intuitionistic form of the characteristic polynomial set with const as constants."

WuRittEqnsSolve::usage = "WuRittEqnsSolve[cspolyset,ord,const] returns the symbolic solution of the characteristic set with const as constants."

ZerosDecomposition::usage = "ZerosDecomposition[polyset,ord,const,opts] returns the zero decomposition solution of the polyset wrt ord."

(*SYSTEM MESSAGE *)

poly::"warning" = "In ps = `1`, lvar is called with constant.";



Begin["`Private`"]


(*THIS CANCELS THE SPELLING CHECKING*)

Off[General::"spell1"];

(*begin of pseudo division of lhspoly to rhspoly wrt ord*)

PolyPRemainder[G_, F_, var_] :=
  Module[{n = 0, quo = 0, R, r, H, h, d, T, L,m},
    R = G; r = Exponent[R, var]; 
    H = F; h = Exponent[H, var];
    m = Exponent[R, var]; 
    d = r - h + 1; 
    If[h <= r, L = LeadCoefficient[H, var]; H = H - L var^h, L = 1];
    While[r >= h || R != 0  , 
    T = var^(r - h)LeadCoefficient[R, var] H;
    R = R - LeadCoefficient[R,var]var^r; 
    R = L R - T; r = Exponent[R, var]; 
    d = d - 1;
    ];
    Return[Expand[(L^d)R]];
]

PseudoRemainder[lhspoly_, rhspoly_, ord___, const___] :=
  Module[{polyquo, polyrem, 
    tmppolyquo, tmppolyrem, polytmplcm, polypseudoquo, polypseudorem, i = 0},
    polyquo = Together@PolynomialQuotient[lhspoly, rhspoly,
       MainVariable[rhspoly, ord, const]];
    polyrem = Together@PolynomialRemainder[lhspoly, rhspoly, MainVariable[rhspoly,
     ord, const]];
    
    tmppolyquo = Denominator[polyquo];
    tmppolyrem = Denominator[polyrem];
    
    polytmplcm = PolynomialLCM[tmppolyquo, tmppolyrem];
    polypseudorem = polytmplcm*polyrem;
    
    Return[Expand[Simplify[polypseudorem]]];
    ]

PseudoResolution[lhspoly_, rhspoly_, ord___, const___] := Module[{polyquo,
     polyrem, tmppolyquo, tmppolyrem, polytmplcm, polypseudoquo,polypseudorem, i = 0}, polyquo = Together@PolynomialQuotient[lhspoly, rhspoly,MainVariable[rhspoly, ord, const]]; polyrem = Together@PolynomialRemainder[lhspoly, rhspoly, MainVariable[rhspoly, ord, const]]; 
tmppolyquo = Denominator[polyquo]; 
tmppolyrem = Denominator[polyrem]; 
polytmplcm = PolynomialLCM[tmppolyquo, tmppolyrem]; 
polypseudoquo = polytmplcm*polyquo;
polypseudorem = polytmplcm*polyrem; 

(*While[(*i <= 10000 &&*)Expand@Simplify[Initial[rhspoly, ord,const]^i*lhspoly] =!= Expand@Simplify[polypseudoquo*rhspoly + polypseudorem], 
    i++;
]; *)

Return[Expand[{polytmplcm,(* i,*) polypseudoquo, polypseudorem}]];

]

(*end of pseudo division of lhspoly to rhspoly wrt ord*)


(*begin of pseudo division of poly to polyset wrt ord*)

AuxPseudoRemainder[poly_, polyset_, ord___, const___] :=
  Module[{len, tmp, mid, i = 1},
    len = Length[polyset];
    tmp = poly;
    While[i <= len, (mid = Evaluate[PseudoRemainder[tmp,polyset[[i]], ord, const]];
        tmp = mid;
        (*If[switch,Print[{StyleForm[StringJoin["STEP:",ToString[i]],FontColor->RGBColor[0,0,1]],StyleForm[tmp,FontColor->RGBColor[1,0,0]]}]];*)
        i++;
        )
      ];
    Return[Expand[tmp]];
    ]

AuxPseudoResolution[poly_, polyset_, ord___, const___] :=
  Module[{len, tmp, mid, i = 1},
    len = Length[polyset];
    tmp = poly;
    While[i <= len, (mid = PseudoResolution[tmp, polyset[[i]], ord, const];
        tmp = Last[mid];
        (*Print[mid];*)
        i++;
        )
      ];
    Return[Expand[mid]];
    ]

(*end of pseudo division of poly to polyset wrt ord*)


(*begin of pseudo division of lhspolyset to rhspolyset wrt ord*)

PseudoRemainderSet[lhspolyset_, rhspolyset_, ord___, const___] :=
  Module[{tmp},
    tmp = AuxPseudoRemainder[#, rhspolyset, ord, const] & /@ lhspolyset;
    Return[tmp];
    ]

PseudoResolutionSet[lhspolyset_, rhspolyset_, ord___, const___] :=
  Module[{tmp},
    tmp = AuxPseudoResolution[#, rhspolyset, ord, const] & /@ lhspolyset;
    Return[Expand[tmp]];
    ]

(*end of pseudo division of lhspolyset to rhspolyset wrt ord*)


(*begin of acsending set part*)

IsAscendingSet[polyset_, ord___,const___] :=
  Module[{tmp, tmpset},
    tmpset = Sort[polyset];
    tmp = PolyVariables /@ tmpset;
    If[IsConstantsIn[tmpset] || MemberQ[Complement[ord, #] & /@ 
    tmp, ord], Return[False], Return[tmpset]];
    Return[{True, Expand[tmpset]}];
    ]

SplitPolySet[polyset_, ord___, const___] :=
  Module[{lst, tmplst, mid, midlst, res},
    lst = {MainVariable[#, ord, const], #} & /@ polyset;
    tmplst = Transpose[Sort[lst]];
    mid = Split@tmplst[[1]];
    midlst = Length /@ mid;
    res = Table[Take[tmplst[[2]], {1 + Apply[Plus, 
    Take[midlst, i - 1]], Apply[Plus, Take[midlst, i]]}], {i, 1, Length@
    midlst}];
    Return[res];
   ]

BasicSet[polyset_, ord___, const___] :=
  Module[{tmp, mid, res},
    tmp = SplitPolySet[polyset, ord, const];
    mid = MinElementPos /@ (
    Exponent[#, 
      MainVariable[#, ord, const]] & /@ SplitPolySet[polyset, ord, const]);
    res = Table[tmp[[i]][[mid[[i]]]], {i, 1, Length[mid]}];
    Return[res];
    ]

MiniAscSet[polyset_, ord___, const___] :=
  Module[{tmp, mid, res},
    tmp = SplitPolySet[polyset, ord, const];
    mid = MinElementPos /@ (
    Exponent[#, 
      MainVariable[#, ord, const]] & /@ SplitPolySet[polyset, ord, const]);
    res = Table[tmp[[i]][[mid[[i]]]], {i, 1, Length[mid]}];
    Return[res];
    ]

(*end of acending set part*)


(*begin of characteristic set part*)
(*ord and const must be specified*)

Attributes[CharacteristicSet] = {HoldFirst}

Options[CharacteristicSet] = {TracePrintOn -> False,MaxSteps -> 100};

CharacteristicSet[polyset_,ord_,const___?ListQ,opts___?OptionQ]:=
  Module[{tmppolys,tmpbass,tmprems,mid,i=1,oldtmpbass,tmp,j=0(*,midres*),
      ordtmp},
    (*If[Length[ord]==0,ord=Union@@(PolyVariables[#,const]&/@polyset)];*)
    ordtmp=orderTransform[ord];
    tmppolys=polyset/.ordtmp[[1]];
    tmpbass=BasicSet[tmppolys,ord/.ordtmp[[1]],const];
    mid=PseudoRemainderSet[tmppolys,tmpbass,ord/.ordtmp[[1]],const];
    tmprems=Union[intTest[mid]];
    (*midres=
          Length@intTest[
              PseudoRemainderSet[polyset,Reverse@tmpbass,ord,const]];*)While[
      Length[tmprems]>0(*&&midres>0*)&&
        i<MaxSteps/.Flatten[{opts,Options[CharacteristicSet]}](*SHOULD BE MODIFYED FOR COMPLEX SITUATION,i.e.Infinity*),
      tmpbass=BasicSet[tmppolys,ord/.ordtmp[[1]],const];
      mid=
        PseudoRemainderSet[tmppolys,Reverse@tmpbass,ord/.ordtmp[[1]],const];
      tmprems=Union[intTest[mid]];
      tmppolys=
        Union[tmpbass,tmprems];(*tmppolys=Union[polyset,tmpbass,tmprems*)If[TracePrintOn/.Flatten[{opts,Options[CharacteristicSet]}],Print[{StyleForm[StringJoin["CS_STEP:",ToString[i]],
              FontColor\[Rule]RGBColor[0,0,1]],
            StyleForm[Simplify@tmpbass/.ordtmp[[2]],FontFamily\[Rule]"Times",
              FontColor\[Rule]RGBColor[1,0,0]]}]];
      If[TracePrintOn/.Flatten[{opts,Options[CharacteristicSet]}],Map[If[IsNewComponent[#],++j]&,tmpbass/.ordtmp[[2]]]];
      (*midres=
            Length@intTest[
                PseudoRemainderSet[polyset,Reverse@Simplify@tmpbass,
                  Revrse@ord/.ordtmp[[1]],const]];*)i++;];
    If[j>0,
      Print[{StyleForm[
            StringJoin["Total ",ToString[j],
              " Branch(s) of New Component(s) Discovered"],Subsubtitle,
            FontColor\[Rule]RGBColor[0,0.6,0]]}]];
    Return[Sort[tmpbass/.ordtmp[[2]]]];
    ]


(* end of characteristic set *)

(*begin of new characteristic form*)

toDoubledZeros[cspolyset_,str_:"00",const___]:=
  Module[{csvarlst,varlst,i=1,tmp},
    csvarlst=Map[PolyVariables[#,const]&,cspolyset];
    varlst=Union@Flatten[csvarlst];
    tmp=Select[
        Flatten[Table[
            If[Not@MemberQ[csvarlst[[i]],varlst[[j]]],{i,j}],{i,1,
              Length[csvarlst]},{j,1,Length[varlst]}],1],#=!=Null&];
    For[i=1,i<=Length[tmp],i++,
      csvarlst=Insert[csvarlst,ToString[str],tmp[[i]]];
      ];
    Return[csvarlst];
    ]

Options[CharacteristicForm] = { Padding -> "00"}

CharacteristicForm[cspolyset_,ord_,const___?ListQ,opts___?OptionQ] :=
  Module[{tmp, mid, res, tmpcs},
    ordtmp=orderTransform[ord];
    tmp = toDoubledZeros[cspolyset, Padding/.Flatten[{opts,Options[CharacteristicForm]}],const]/.ordtmp[[1]];
    mid = MapThread[{#1, #2} &, {cspolyset/.ordtmp[[1]], tmp}];
    res = MatrixForm[mid/.ordtmp[[2]]];
    Return[res];
    ]

(* end of new characteristic form*)

(* begin of old characteristic form *)

(*end of characteristic set part*)

(*begin of wuritteqnssolve*)

WuRittEqnsSolve[cspolyset_,ord_,const___]:=
  Module[{tmp,mainvars,sollen,j=2,mid,result,cslen=Length@cspolyset,sols},
    ordtmp=orderTransform[ord];
    sols=Table[0,{i,1,Length[cspolyset(*/.ordtmp[[1]]*)]}];
    mainvars=Last/@((PolyVariables[#,const]&/@cspolyset)/.ordtmp[[1]]);
    tmp=MapThread[Solve[#1\[Equal]0,#2]&,{cspolyset/.ordtmp[[1]],mainvars}];
    sols[[1]]=Flatten[First[tmp]];
    sollen=Length[sols[[1]]];
    (*Print[{solsts,sols,sollen,cslen}];*)While[j\[LessEqual]cslen,
      mid=Simplify@
          Flatten@Table[
              ReplaceAll[tmp[[j]],
                Flatten@Map[Take[#,{i,i}]&,Take[sols,j-1]]],{i,1,sollen}];
      sols[[j]]=mid;
      (*Print@mid;*)j++;];
    res=Flatten/@Table[Map[Take[#,{i,i}]&,sols],{i,1,sollen}];
    Return[res/.ordtmp[[2]]];]

(*end of wuritteqnssolve*)

(*begin of zeros decompostion*)

csInitEqnsol[cset_,ord_,const___]:=
  Module[{sl,init,res},
    sl=WuRittEqnsSolve[cs,ord,const];
    init=Times@@(Initial[#,ord]&/@cs);
    res=Map[If[Evaluate@(init/.#)=!=0,#,{}]&,sl];
    Return[res];
    ]


Options[ZerosDecomposition]={TracePrintOn\[Rule]True,DecompositionType\[Rule]1}~
      Join~Options[CharacteristicSet];


ZerosDecomposition[polyset_,ord_,const___,opts___]:=
  Module[{i=0,tmpcs,init,mid,tmpmidset,tmpmidsol,res},
    tmpcs=CharacteristicSet[polyset,ord,const,opts];
    init=Initial[#,ord]&/@tmpcs;
    mid=Map[If[IsCompatibleSet[#],CharacteristicSet[#,ord,const,opts],#]&,
        Map[Union[polyset,#]&,Map[{#}&,init]]];
    tmpmidset=Flatten[Map[If[IsCompatibleSet[#,const],#,{}]&,mid],1];
    tmpmidsol=
      Flatten[Map[
          If[IsCompatibleSet[#,const],WuRittEqnsSolve[#,ord,const],{}]&,mid],
        1];(*Select[mid,IsCompatibleSet[#,const]&];*)
    Return[{tmpmidset,tmpmidsol}];
    ]

(*end of zeros decompostion*)

(*this ensures the spelling checking*)

On[General::"spell1"];

End[ ]

SetAttributes[ WuRittSolva ,ReadProtected];

Protect[ CharacteristicSet,CharacteristicForm];

EndPackage[ ]

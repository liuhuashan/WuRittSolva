(* :Title: WuRittProver Part of WuRittSolva *)

(* :Author:

   Huashan Liu,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Republic of China
   E-Mail:liukaitanpidi@sina.com
   HomePage:http://magicm.51.net

   Instructor:
   Associate Prof. Huang DongWei,
   Department of Applied Mathematics,
   School of Science,Tianjin Polytechnic University, 300160
   Tianjin, People's Repulic of China

*)

(* :Summary:
  
   This package is written for implement a smart geometry theorem prover by WuRitt Process. The kernel basis is the algebraic nulls theorem created by Acdemician Wu Wen-Jun.

*)

(* :Context: WuRittSolva`WuRittProver` *)

(* :Package Version: 1.0 *)

(* :Copyright: Copyright 2005 *)

(* :History:1.0: original version, 2005.*)

(* :Keywords: WuRitt Process, WuRittSolva*)

(* :Source: None. *)

(* :Warning: Expands the definition of Column. *)

(* :Mathematica Version: 4.2 or later *)

(* :Limitation: None known. *)

(* :Discussion: 

   The key problem is focused on how to fix a proper characteristic set. If proper, the  following steps maybe become more elegant, else more complex. In the concrete steps, factorization on rational filed is helpful to simplify the computation by the Nulls Configuration Theorems or Wu Wentsun Principles.

*)

(* :Reference:

   [1].Original algorithm of the general process is out of Mr. Wu Wentsun 's works(like ON MATHEMATICS MECHANNIZATION) and some others' books such as SELECTED PAPERS IN SIMBOLIC COMPUTATION(By Doc. Wang DongMing etc.), ARITHMETIC  ALGEBRA(By Bhubaneswar Mishra),etc..

   [2].Referential realization in any computer algebra language is helpful.The available package is WSOLVE in Maple format at present.
   Note:
   WSOLVE of Maple V realease 3 is developped by Doctor Wang DingKang,
   Mathematics Mechanization Research Center(abbrev. MMRC),
   Chinese Academic Scinica(abbrev. CAS)
   WebAdress:http://mmrc.iss.ac.cn/
   
   [3].Stephen Wolfram,The Mathematica Book,4th ed.(Wolfram Media/Cambridge University Press, 1999).

*)


(* :History: File created on March 4th,2005 *)

BeginPackage["WuRittSolva`WuRittProver`", {"WuRittSolva`Master`"},{"WuRittSolva`WuRittSolva`"}]

(*usage for system functions*)

AuxProverRemainder::usage = "AuxProverRemainder[poly,polyset,ord,const,opts] is a auxilary function for WuRittProver."

WuRittProver::usage = "WuRittProver[lhspolyset,rhspoly,ord,const,opts] returns the boolean value True if the theorem is Ture wrt ord with const as constants,else False. If swith is True then it lists the Process else not."

IsNewComponent::usage = "IsNewComponent[lhspoly] returns the boolean value True if there are new compenents in lhspoly else not."

WuRittSmartProver::usage = "WuRittSmartProver[coord_,{thmcfg_,thmcnd_},ord,const,opts] is an integrated prover for geometry theorem proving, in which coord is the coordination,thmcfg is the theorem configuration and thmcnd is the conclusion wrt ord with const as constants."

(*SYSTEM MESSAGES *)

poly::"warning" = "In ps = `1`, lvar is called with constant.";


Begin["`Private`"]


(*this cancels the spelling checking*)

Off[General::"spell1"];

(*begin of wurittprover part*)

IsNewComponent[lhspoly_]:=
  Module[{tmp,res},
    tmp=FactorList[lhspoly];
    res=If[Length[tmp]>2,
        Table[
          Print[{StyleForm[StringJoin["A New Component:",ToString[i]],
                FontColor\[Rule]RGBColor[0,0.6,0]],
              StyleForm[tmp[[2+i]][[1]]^tmp[[2+i]][[2]],FontFamily->"Times",
                FontColor\[Rule]RGBColor[1,0,0.5]]}],{i,1,Length[tmp]-2}];
        True,False];
    Return[res];
    ]

Options[AuxProverRemainder] ={TraceProverOn->True}~Join~Options[CharacteristicSet]

AuxProverRemainder[poly_, polyset_,ord_:{},const___?ListQ,opts___?OptionQ] :=
  Module[{len, tmp, mid, i = 1},
    len = Length[polyset];
    tmp = poly;
    While[i <= len, (mid = Evaluate[PseudoRemainder[tmp,polyset[[i]], ord, const]];
        tmp = mid;   If[TraceProverOn/.Flatten[{opts}],Print[{StyleForm[StringJoin["WRP_STEP:",ToString[i]],FontColor->RGBColor[0,0,1]],StyleForm[Simplify[tmp],FontFamily->"Times",FontColor->RGBColor[1,0,0]]}]];
        i++;
        )
      ];
    Return[Expand[tmp]];
    ]

Options[WuRittProver] = {TraceProverOn->True}~Join~Options[CharacteristicSet]

WuRittProver[lhspolyset_, rhspoly_, ord_:{}, const___?ListQ,opts___?OptionQ] :=
  Module[{tmp,res},
    tmp = AuxProverRemainder[rhspoly, lhspolyset, ord, const,opts];
    res = If[Simplify[tmp] === 0, True, False];
    Return[res];
    ]

Options[WuRittSmartProver] = { TraceCharacteristicSetOn -> True,TraceProverOn -> True}~Join~Options[CharacteristicSet]

WuRittSmartProver[coord_?ListQ,{thmcfg_?ListQ,thmcnd_?ListQ},ord_:{},const__?ListQ,opts___?OptionQ]:=
  Module[{hypset,cndset,defcs,test,n=1,res={}},hypset=thmcfg/.coord;
    cndset=thmcnd/.coord;
    Print[
      StyleForm["WRSP_Step_I: Now Solving the Characteristic Set",
        FontSize\[Rule]18,FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
        FontColor\[Rule]RGBColor[0,0,1]]];
    test=TraceCharacteristicSetOn/.Flatten[{opts}];
    defcs=CharacteristicSet[hypset,ord,const,TracePrintOn->test];
    If[test,Print@CharacteristicForm[defcs,ord,const,Padding->"00"]];
    Print[
      StyleForm["WRSP_Step_II: Now Proving the Theorem(s)",FontSize\[Rule]18,
        FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
        FontColor\[Rule]RGBColor[0,0,1]]];
    While[n\[LessEqual]Length[cndset],
        Print[StyleForm[
            StringJoin["WRSP_SubStep_",ToString[n],"_I: Now Proving the ",
              ToString[n],"(th) Theorem"],FontSize\[Rule]15,
            FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
            FontColor\[Rule]RGBColor[1,0,0]]];
        test=TraceProverOn/.Flatten[{opts}];
         (*Input["Do you want to view the Deduction Process of the Theorem(s) \
? True to View else False."];*)
        tmp=Timing@WuRittProver[Reverse@defcs,cndset[[n]],ord,const,TraceProverOn->test];
        Print[
          StyleForm[
            StringJoin["WRSP_SubStep_",ToString[n],"_II: The ",ToString[n],
              "(th) Theorem is ",ToString[tmp[[2]]]],FontSize\[Rule]15,
            FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
            FontColor\[Rule]RGBColor[1,0,0]]];
        n++;
        res=AppendTo[res,tmp]] Print[
        StyleForm[
          "WRSP_Step_III: Now Checking the Initials & the Algebraic \
Configuration",FontSize\[Rule]18,FontFamily\[Rule]"Times",
          FontWeight\[Rule]"Bold",FontColor\[Rule]RGBColor[0,0,1]]];
    Print[{StyleForm["The Initials: ",FontSize\[Rule]15,
          FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
          FontColor\[Rule]RGBColor[0,0,1]],
        StyleForm[Union@Simplify[Initial[#,ord,const]&/@defcs],
          FontSize\[Rule]15,FontFamily\[Rule]"Times",
          FontColor\[Rule]RGBColor[1,0,0]]}];
    Print[{StyleForm["The Algebraic Configuration: ",FontSize\[Rule]15,
          FontFamily\[Rule]"Times",FontWeight\[Rule]"Bold",
          FontColor\[Rule]RGBColor[0,0,1]],
        StyleForm[Union@Simplify[WuRittEqnsSolve[defcs,ord,const]],
          FontSize\[Rule]15,FontFamily\[Rule]"Times",
          FontColor\[Rule]RGBColor[1,0.,0.]]}];
    Return[res];]

(*end of  wurittprover part*)


(*this ensures the spelling checking*)

On[General::"spell1"];


End[ ]

SetAttributes[ WuRittProver ,ReadProtected];

Protect[ WuRittProver ];
EndPackage[ ]
